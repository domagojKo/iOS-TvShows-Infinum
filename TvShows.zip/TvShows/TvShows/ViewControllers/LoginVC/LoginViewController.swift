//
//  LoginViewController.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import UIKit
import KeychainAccess

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var visibilityButton: UIButton!
    @IBOutlet weak var checkmarkButton: UIButton!
    
    var userDefaults: UserDefaults {
        return UserDefaults.standard
    }
    
    var emailFieldCheck = false {
        didSet {
            correctInputs = emailFieldCheck && passFieldCheck
        }
    }
    
    var passFieldCheck = false {
        didSet {
            correctInputs = emailFieldCheck && passFieldCheck
        }
    }
    
    var correctInputs = false {
        didSet {
            loginButton.isEnabled = correctInputs
            loginButton.alpha = correctInputs ? 1.0 : 0.6
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupLoginButton()
        
        let tap = UITapGestureRecognizer(target: self.view,action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
        emailTextField.addTarget(self, action: #selector(checkEmail), for: .editingChanged)
        passwordTextField.addTarget(self, action: #selector(checkPassword), for: .editingChanged)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    @IBAction func onVisibilityButtonTapped(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        if sender.isSelected {
            passwordTextField.isSecureTextEntry = false
        } else {
            passwordTextField.isSecureTextEntry = true
        }
    }
    
    @IBAction func onRememberMeBtnTapped(_ sender: UIButton) {
        sender.isSelected.toggle()
    }
    
    @IBAction func onLogin(_ sender: UIButton) {
        guard let email = emailTextField.text, email.isValidEmail(),
            let pass = passwordTextField.text else { return }
        
        self.fetchingToken(email: email, password: pass)
    }
    
    @objc
    func checkEmail() {
        guard let email = emailTextField.text, email.isValidEmail() else {
            emailFieldCheck = false
            return
        }
        emailFieldCheck = true
    }
    
    @objc
    func checkPassword() {
        guard let pass = passwordTextField.text, pass.count > 6 else {
            passFieldCheck = false
            return
        }
        passFieldCheck = true
    }
    
    func fetchingToken(email: String, password: String) {
        LoginAPI.instance.fetchToken(email: email, password: password) { [weak self] data, error in
            guard let self = self else { return }
            if let err = error {
                DispatchQueue.main.async {
                    self.showAlert(description: err.localizedDescription)
                }
            }
            
            guard let token = data else { return }
            
            if self.checkmarkButton.isSelected {
                self.userDefaults.set(true, forKey: "userIsRemembered")
                MyKeychain.keychain[KeychainProperties.userEmail.rawValue] = email
                MyKeychain.keychain[KeychainProperties.userPassword.rawValue] = password
            }
            
            MyKeychain.keychain[KeychainProperties.userToken.rawValue] = token.token
            self.presentShowVC()
        }
    }
    
    func presentShowVC() {
        let storyboard = UIStoryboard(name: "Shows", bundle: nil)
        let showVC = storyboard.instantiateViewController(withIdentifier: "ShowsViewController") as! ShowsViewController
        navigationController?.pushViewController(showVC, animated: true)
    }
    
    deinit {
        print("deinit loginVC.")
    }
}

extension LoginViewController {
    func setupLoginButton() {
        self.loginButton.layer.cornerRadius = 4
        self.loginButton.alpha = 0.6
    }
}
