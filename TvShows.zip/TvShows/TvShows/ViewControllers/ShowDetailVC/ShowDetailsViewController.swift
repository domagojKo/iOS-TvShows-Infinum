//
//  ShowDetailsViewController.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 17/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import UIKit

class ShowDetailsViewController: UIViewController {
    
    @IBOutlet weak var showDetailsTableView: UITableView!
    
    let refreshControl = UIRefreshControl()
    
    var showId: String?
    var details: ShowDetails? {
        didSet {
            self.setupTableView()
        }
    }
    var episodes = [Episode]() {
        didSet {
            DispatchQueue.main.async {
                self.showDetailsTableView.reloadData()
            }
        }
    }
    
    var sortedEpisodes: [Episode] {
        return episodes.sorted{ (ep1, ep2) -> Bool in
            if ep1.season != ep2.season {
                return ep1.season > ep2.season
            }
            
            return ep1.episodeNumber > ep2.episodeNumber
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.fetchDataForTvShow()
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    func setupTableView() {
        showDetailsTableView.separatorStyle = .none
        
        let cellNibName = "TvShowEpisodeCell"
        showDetailsTableView.register(UINib(nibName: cellNibName, bundle: nil),
                                      forCellReuseIdentifier: TvShowEpisodeCell.cellReuseIdentifier)
        
        let cellName = "TvShowDetailCell"
        showDetailsTableView.register(UINib(nibName: cellName, bundle: nil),
                                      forCellReuseIdentifier: TvShowDetailCell.cellReuseIdentifier)
        
        showDetailsTableView.dataSource = self
        
        showDetailsTableView.refreshControl = refreshControl
    }
    
    func fetchDataForTvShow() {
        guard let token = MyKeychain.keychain[KeychainProperties.userToken.rawValue], let showId = showId else {
            return self.showAlert(description: "Try to login again.")
        }
        
        let headers = ["Authorization": token]
        self.fetchTvShowDetailData(headers: headers, showId: showId)
        self.fetchDataForEpisodeCell(headers: headers, showId: showId)
    }
    
    func fetchTvShowDetailData(headers: [String : String], showId: String) {
        TvShowDetailsAPI.instance.fetchTvShowDetails(headers: headers, showId: showId) { [weak self] data, error in
            guard let self = self else { return }
            if let err = error {
                DispatchQueue.main.async {
                    self.showAlert(description: err.localizedDescription)
                }
            }
            
            guard let showDetails = data else { return }
            self.details = showDetails
        }
    }
    
    func fetchDataForEpisodeCell(headers: [String : String], showId: String) {
        TvShowDetailsAPI.instance.fetchTvShowEpisode(headers: headers, showId: showId) { [weak self] data, error in
            guard let self = self else { return }
            if let err = error {
                DispatchQueue.main.async {
                    self.showAlert(description: err.localizedDescription)
                }
            }
            
            guard let episodes = data else { return }
            self.episodes = episodes
        }
    }
    
    @objc
    func refreshData() {
        self.fetchDataForTvShow()
        DispatchQueue.main.async {
            self.showDetailsTableView.reloadData()
        }
        
        refreshControl.endRefreshing()
    }
    
    @IBAction func onBackButtonTapped(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    deinit {
        print("Show details deinit")
    }
}

extension ShowDetailsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return episodes.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: TvShowDetailCell.cellReuseIdentifier, for: indexPath) as! TvShowDetailCell
            
            if let showDetails = details {
                cell.setupDetailCell(showDetails: showDetails, episodesNumber: episodes.count)
            }
            return cell
            
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: TvShowEpisodeCell.cellReuseIdentifier, for: indexPath) as! TvShowEpisodeCell
            
            let episode = sortedEpisodes[indexPath.row - 1]
            
            cell.setupEpisodeCell(episode: episode)
            
            return cell
        }
    }
}
