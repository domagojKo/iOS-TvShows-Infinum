//
//  ShowsViewController.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import Foundation
import UIKit
import KeychainAccess

class ShowsViewController: UIViewController {
    
    @IBOutlet weak var showTableView: UITableView!
    
    var showHeaderView: ShowsHeaderView!
    var appDelegate: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    let cellReuseIdentifier = "cellMain"
    
    var shows = [Show]() {
        didSet {
            DispatchQueue.main.async {
                self.showTableView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupShowTableView()
        self.fetchShowData()
        
        showHeaderView.logoutButton.addTarget(self, action: #selector(onLogoutBtnTapped), for: .touchUpInside)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    func setupShowTableView() {
        showTableView.separatorStyle = .none
        
        let cellNibName = "ShowTableViewCell"
        showTableView.register(UINib(nibName: cellNibName, bundle: nil),
                               forCellReuseIdentifier: cellReuseIdentifier)
        
        showTableView.delegate = self
        showTableView.dataSource = self
        
        showHeaderView = ShowsHeaderView(frame: CGRect(x: 0, y: 0, width: showTableView.frame.width, height: 80))
        showTableView.tableHeaderView = showHeaderView
    }
    
    func fetchShowData() {
        guard let token = MyKeychain.keychain[KeychainProperties.userToken.rawValue] else {
            return self.showAlert(description: "Session Expired, log in back.")
        }
        
        let headers = ["Authorization": token]
        
        TvShowsAPI.instance.fetchTvShows(headers: headers) { [weak self] data, error in
            guard let self = self else { return }
            if let err = error {
                DispatchQueue.main.async {
                    self.showAlert(description: err.localizedDescription)
                }
            }
            
            guard let shows = data else { return }
            self.shows = shows
        }
    }
    
    @objc func onLogoutBtnTapped() {
        do {
            try MyKeychain.keychain.removeAll()
        } catch let error {
            print("error: \(error)")
        }
        
        UserDefaults.standard.set(false, forKey: "userIsRemembered")
        
        let storyboard = UIStoryboard(name: "Login", bundle: nil)
        let loginVC = storyboard.instantiateViewController(withIdentifier: "nav1") 
        appDelegate.window?.rootViewController = loginVC
        appDelegate.window?.makeKeyAndVisible()
    }
    
    func presentDetailsVC(id: String) {
        let storyboard = UIStoryboard(name: "ShowDetails", bundle: nil)
        let showDetailVC = storyboard.instantiateViewController(withIdentifier: "ShowDetailsViewController") as! ShowDetailsViewController
        showDetailVC.showId = id
        navigationController?.pushViewController(showDetailVC, animated: true)
    }
    
    deinit {
        print("Shows VC deinit")
    }
}

extension ShowsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let showId = shows[indexPath.row].id
        self.presentDetailsVC(id: showId)
    }
}

extension ShowsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.shows.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath) as! ShowTableViewCell
        
        let show = shows[indexPath.row]
        
        cell.setupTvShowCell(show: show)
        
        return cell
    }
}

