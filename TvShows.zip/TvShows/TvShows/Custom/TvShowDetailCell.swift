//
//  TvShowDetailCell.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 17/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import UIKit

class TvShowDetailCell: UITableViewCell {
    @IBOutlet weak var showImageView: UIImageView!
    @IBOutlet weak var showTitleLabel: UILabel!
    @IBOutlet weak var showDescriptionTextView: UITextView!
    @IBOutlet weak var episodesLabel: UILabel!
    
    @IBOutlet weak var showDescTextViewHeightConstraint: NSLayoutConstraint!
    
    static let cellReuseIdentifier = "detailCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }
    
    func setupDetailCell(showDetails: ShowDetails, episodesNumber: Int) {
        let url = showDetails.imageUrl
        if let imageURL = URL(string: kBaseAPI + url) {
            self.showImageView.kf.setImage(with: imageURL)
            
            let gradient = CAGradientLayer()
            gradient.frame = showImageView.bounds
            gradient.colors = [UIColor.clear.cgColor, UIColor.black.cgColor, UIColor.black.cgColor, UIColor.clear.cgColor]
            gradient.locations = [0, 0, 0.9, 1]
            showImageView.layer.mask = gradient
        }
        
        showTitleLabel.text = showDetails.title
        if !showDetails.description.isEmpty {
            showDescriptionTextView.text = showDetails.description
            showDescriptionTextView.sizeToFit()
            
//             showDescTextViewHeightConstraint.constant = self.showDescriptionTextView.contentSize.height
        } else {
            showDescriptionTextView.isHidden = true
        }
       
        episodesLabel.attributedText = attributedEpisodeText(numberOfEpisodes: episodesNumber)
    }
    
    func attributedEpisodeText(numberOfEpisodes: Int) -> NSMutableAttributedString {
        let episode = "Episodes  "
        let baseFont = UIFont(name: "Arial", size: 18)
        let episodeAttributes = [NSMutableAttributedString.Key.font: baseFont,
                                 NSMutableAttributedString.Key.foregroundColor: UIColor.black]
        let attrString = NSMutableAttributedString(string: episode, attributes: episodeAttributes as [NSAttributedString.Key : Any])
        
        let numberOfEpisodesAsString = String(numberOfEpisodes)
        let font = UIFont(name: "Arial", size: 16)
        let nmbOfEpisodeAttr = [NSMutableAttributedString.Key.font: font,
                          NSMutableAttributedString.Key.foregroundColor: UIColor.lightGray]
        let attrString1 = NSMutableAttributedString(string: numberOfEpisodesAsString, attributes: nmbOfEpisodeAttr as [NSAttributedString.Key : Any])
        
        attrString.append(attrString1)
        
        return attrString
    }
}
