//
//  TvShowDetailCell.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 17/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import UIKit

class TvShowEpisodeCell: UITableViewCell {

    @IBOutlet weak var epSeNumber: UILabel!
    @IBOutlet weak var episodeTitle: UILabel!
    
    static let cellReuseIdentifier = "cellEpisode"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        epSeNumber.text = nil
        episodeTitle.text = nil
    }
    
    func setupEpisodeCell(episode: Episode) {
        epSeNumber.text = "S\(episode.season) E\(episode.episodeNumber)"
        episodeTitle.text = episode.title
    }
}
