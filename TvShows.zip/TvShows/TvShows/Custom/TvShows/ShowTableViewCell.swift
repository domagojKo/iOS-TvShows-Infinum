//
//  ShowTableViewCell.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import UIKit
import Kingfisher

class ShowTableViewCell: UITableViewCell {
    
    @IBOutlet weak var tvShowImageView: UIImageView! {
        didSet {
            tvShowImageView.layer.cornerRadius = 3
        }
        
    }
    
    @IBOutlet weak var tvShowTitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        tvShowImageView.image = nil
        tvShowTitleLabel.text = nil
    }
    
    func setupTvShowCell(show: Show) {
        let url = show.imageUrl
        if let imageURL = URL(string: kBaseAPI + url) {
            self.tvShowImageView.kf.setImage(with: imageURL)
        }
        
        self.tvShowTitleLabel.text = show.title
    }
}
