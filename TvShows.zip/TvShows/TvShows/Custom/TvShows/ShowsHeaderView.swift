//
//  ShowsHeaderView.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 15/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import UIKit

class ShowsHeaderView: UIView {

     let showTitle = UILabel()
     let logoutButton = UIButton()

     override init(frame: CGRect) {
         super.init(frame: frame)
         self.setupViews()
     }
     
     required init?(coder aDecoder: NSCoder) {
         fatalError("Has to be implemented as it is required but will never be used")
     }
     
     func setupViews() {
         self.addSubviews()
         self.setupStyleOfSubviews()
         self.setupLayout()
     }
     
     func addSubviews() {
         self.addSubview(showTitle)
         self.addSubview(logoutButton)
     }
     
     func setupStyleOfSubviews() {
         self.showTitle.textColor = .black
         self.showTitle.font = UIFont(name: "Arial", size: 30)
         self.showTitle.text = "Shows"
        
        self.logoutButton.backgroundColor = .clear
        self.logoutButton.setImage(UIImage(named: "ic-logout"), for: .normal)
     }
     
     func setupLayout() {
         showTitle.translatesAutoresizingMaskIntoConstraints = false
         NSLayoutConstraint.activate([
             showTitle.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20),
             showTitle.trailingAnchor.constraint(equalTo: self.logoutButton.leadingAnchor, constant: -20),
             showTitle.topAnchor.constraint(equalTo: self.topAnchor, constant: 20)])
         
         logoutButton.translatesAutoresizingMaskIntoConstraints = false
         NSLayoutConstraint.activate([
             logoutButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 20),
             logoutButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20),
             logoutButton.widthAnchor.constraint(equalToConstant: 40),
             logoutButton.heightAnchor.constraint(equalToConstant: 40)])
     }

}
