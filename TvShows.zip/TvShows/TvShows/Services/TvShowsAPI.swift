//
//  TvShowsAPI.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import Foundation
import Alamofire

class TvShowsAPI {
    typealias FetchTvShowsCompletion = (([Show]?, Error?) -> Void)
    
    static let instance = TvShowsAPI()
    
    func fetchTvShows(headers: [String : String], completion: @escaping FetchTvShowsCompletion) {
        Alamofire
            .request(kShowsAPI, method: .get,
                     parameters: nil, encoding: JSONEncoding.default,
                     headers: headers)
            .validate()
            .responseDecodableObject(queue: nil, keyPath: "data", decoder: JSONDecoder()) { (response: DataResponse<[Show]>) in
                guard response.error == nil else {
                    completion(nil, response.error!)
                    return
                }
                
                if let data = response.value {
                    completion(data, nil)
                }
        }
    }
}
