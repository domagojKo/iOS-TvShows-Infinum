//
//  TvShowDetailsAPI.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 17/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import Foundation
import Alamofire

class TvShowDetailsAPI {
    typealias FetchTvShowDetailsCompletion = ((ShowDetails?, Error?) -> Void)
    typealias FetchTvShowEpisodes = (([Episode]?, Error?) -> Void)
    
    static let instance = TvShowDetailsAPI()
    
    func fetchTvShowDetails(headers: [String : String], showId: String, completion: @escaping FetchTvShowDetailsCompletion) {
        Alamofire
            .request(kShowDetails + "\(showId)", method: .get,
                     parameters: nil, encoding: JSONEncoding.default,
                     headers: headers)
            .validate()
            .responseDecodableObject(queue: nil, keyPath: "data", decoder: JSONDecoder()) { (response: DataResponse<ShowDetails>) in
                guard response.error == nil else {
                    completion(nil, response.error!)
                    return
                }
                
                if let data = response.value {
                    completion(data, nil)
                }
        }
    }
    
    func fetchTvShowEpisode(headers: [String : String], showId: String, completion: @escaping FetchTvShowEpisodes) {
        Alamofire
            .request(kShowDetails + "\(showId)" + "/episodes", method: .get,
                     parameters: nil, encoding: JSONEncoding.default,
                     headers: headers)
            .validate()
            .responseDecodableObject(queue: nil, keyPath: "data", decoder: JSONDecoder()) { (response: DataResponse<[Episode]>) in
                guard response.error == nil else {
                    completion(nil, response.error!)
                    return
                }
                
                if let data = response.value {
                    completion(data, nil)
                }
        }
    }
}
