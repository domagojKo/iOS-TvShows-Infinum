//
//  LoginAPI.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import Foundation
import Alamofire
import CodableAlamofire

class LoginAPI {
    typealias FetchTokenCompletion = ((Token?, Error?) -> Void)
    
    static let instance = LoginAPI()

    func fetchToken(email: String, password: String, completion: @escaping FetchTokenCompletion) {
        let parameters = ["email" : email, "password" : password]
        
        Alamofire
            .request(kLoginAPI, method: .post,
                          parameters: parameters,
                          encoding: JSONEncoding.default,
                          headers: nil)
            .validate()
            .responseDecodableObject(queue: nil, keyPath: "data", decoder: JSONDecoder()) { (response: DataResponse<Token>) in
                guard response.error == nil else {
                    completion(nil, response.error)
                    return
                }
                
                if let data = response.value {
                    completion(data, nil)
                }
        }
    }
}
