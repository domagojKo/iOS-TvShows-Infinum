//
//  AppDelegate.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        
        if !isRemember() {
            let storyboard = UIStoryboard(name: "Login", bundle: nil)
            let loginVC = storyboard.instantiateViewController(withIdentifier: "nav1") 
            window?.rootViewController = loginVC
            window?.makeKeyAndVisible()
        } else {
            let storyboard = UIStoryboard(name: "Shows", bundle: nil)
            let showVC = storyboard.instantiateViewController(withIdentifier: "nav2") 
            window?.rootViewController = showVC
            window?.makeKeyAndVisible()
        }       
        return true
    }
    
    func isRemember() -> Bool {
        return UserDefaults.standard.bool(forKey: "userIsRemembered")
    }
}

