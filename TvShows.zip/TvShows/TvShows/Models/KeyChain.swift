//
//  KeyChain.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import Foundation
import KeychainAccess

struct MyKeychain {
    static let keychain = Keychain(service: "c.TvShows")
}

enum KeychainProperties: String {
    case userToken = "userToken"
    case userEmail = "email"
    case userPassword = "password"
}
