//
//  APIKeys.swift
//  TvShows
//
//  Created by Domagoj Kolaric on 14/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import Foundation

let kLoginAPI = "https://api.infinum.academy/api/users/sessions"
let kShowsAPI = "https://api.infinum.academy/api/shows"
let kBaseAPI = "https://api.infinum.academy"
let kShowDetails = "https://api.infinum.academy/api/shows/"
