//
//  TvShowsTests.swift
//  TvShowsTests
//
//  Created by Domagoj Kolaric on 18/08/2020.
//  Copyright © 2020 Domagoj Kolaric. All rights reserved.
//

import XCTest
@testable import TvShows

class TvShowsTests: XCTestCase {
    var sut: URLSession!

    override func setUp() {
      super.setUp()
      sut = URLSession(configuration: .default)
    }

    override func tearDown() {
      sut = nil
      super.tearDown()
    }
    
    func testValidCallToFetchTvShowsGetsHttpStatusCode200() {
        let url = URL(string: kShowsAPI)
        
        let promise = expectation(description: "Status code: 200")
        
        let dataTask = sut.dataTask(with: url!) { data, response, error in
            if let error = error {
                XCTFail("Error: \(error.localizedDescription).")
                return
            } else if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode == 200 {
                    promise.fulfill()
                } else {
                    XCTFail("Status code: \(statusCode).")
                }
            }
        }
        dataTask.resume()
        wait(for: [promise], timeout: 6)
    }
    
    func testCallToTvShowsCompletes() {
      let url = URL(string: kBaseAPI)
      
      let promise = expectation(description: "Completion handler invoked")
      var statusCode: Int?
      var responseError: Error?
      
      let dataTask = sut.dataTask(with: url!) { data, response, error in
        statusCode = (response as? HTTPURLResponse)?.statusCode
        responseError = error
        promise.fulfill()
      }
      dataTask.resume()
      
      wait(for: [promise], timeout: 5)
      
      XCTAssertNil(responseError)
      XCTAssertEqual(statusCode, 200)
    }
}
